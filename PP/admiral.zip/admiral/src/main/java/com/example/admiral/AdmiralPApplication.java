package com.example.admiral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdmiralPApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdmiralPApplication.class, args);
	}

}
